To install this package follow run the given command
pip install give_the_.whl file name